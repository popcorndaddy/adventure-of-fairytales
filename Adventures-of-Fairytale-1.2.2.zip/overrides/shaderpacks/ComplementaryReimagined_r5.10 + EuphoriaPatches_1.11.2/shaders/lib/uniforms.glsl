/*----------------------------------------------------------------------------------------------
        _____                                                                    _____
        ( ___ )                                                                  ( ___ )
        |   |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|   |
        |   | ██╗   ██╗███╗   ██╗██╗███████╗ ██████╗ ██████╗ ███╗   ███╗███████╗ |   |
        |   | ██║   ██║████╗  ██║██║██╔════╝██╔═══██╗██╔══██╗████╗ ████║██╔════╝ |   |
        |   | ██║   ██║██╔██╗ ██║██║█████╗  ██║   ██║██████╔╝██╔████╔██║███████╗ |   |
        |   | ██║   ██║██║╚██╗██║██║██╔══╝  ██║   ██║██╔══██╗██║╚██╔╝██║╚════██║ |   |
        |   | ╚██████╔╝██║ ╚████║██║██║     ╚██████╔╝██║  ██║██║ ╚═╝ ██║███████║ |   |
        |   |  ╚═════╝ ╚═╝  ╚═══╝╚═╝╚═╝      ╚═════╝ ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝ |   |
        |___|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|___|
        (_____)                              (thanks to isuewo and SpacEagle17)  (_____)

---------------------------------------------------------------------------------------------*/
uniform bool isRightHanded = true;
uniform bool heavyFog = false;
uniform bool firstPersonCamera = true;
uniform bool is_invisible = false;
uniform bool isElytraFlying = false;

uniform int renderStage;
uniform int blockEntityId;
uniform int currentRenderedItemId;
uniform int entityId;
uniform int frameCounter;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;
uniform int isEyeInWater;
uniform int moonPhase;
uniform int worldTime;
uniform int worldDay;
#if MC_VERSION > 11800 && defined OVERWORLD
    uniform int bedrockLevel = -64;
#else
    uniform int bedrockLevel = 0;
#endif
uniform int hideGUI;

uniform float aspectRatio;
uniform float blindness;
uniform float darknessFactor;
uniform float darknessLightFactor;
uniform float maxBlindnessDarkness;
uniform float eyeAltitude;
uniform float frameTime;
#ifdef FROZEN_TIME
    float frameTimeCounter = 10;
#else
    uniform float frameTimeCounter;
#endif
uniform float far;
uniform float near;
uniform float nightVision;
uniform float rainStrength;
uniform float screenBrightness;
uniform float viewHeight;
uniform float viewWidth;
uniform float wetness;
uniform float sunAngle;
uniform float playerMood;
uniform float cloudHeight = 192.0;
uniform float currentPlayerArmor = 0.0;

uniform ivec2 atlasSize;
uniform ivec2 eyeBrightness;
uniform ivec2 eyeBrightnessSmooth;

uniform vec3 cameraPosition;
uniform vec3 fogColor;
uniform vec3 previousCameraPosition;
uniform vec3 skyColor;
uniform vec3 eyePosition;
uniform vec3 relativeEyePosition;
uniform vec3 playerLookVector;

uniform vec4 entityColor;
uniform vec4 lightningBoltPosition = vec4(0.0);

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowProjectionInverse;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D colortex8;
uniform sampler2D colortex12;
uniform sampler2D colortex13;
uniform sampler2D colortex14;
uniform sampler2D colortex15;

#if defined SS_BLOCKLIGHT || defined PHOTONICS_LIGHTING
uniform sampler2D colortex9;
uniform sampler2D colortex10;
#endif

#ifdef PHOTONICS_LIGHTING
uniform sampler2D colortex11;
uniform sampler2D colortex20;
uniform float photonicsMasterTimer;
uniform float photonicsOutsideRange;
#endif

uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D depthtex2;
uniform sampler2D gaux2;
uniform sampler2D gaux4;
uniform sampler2D normals;
uniform sampler2D noisetex;
uniform sampler2D specular;
uniform sampler2D tex;

// MC 26.1 only: Sodium terrain/translucent bind an isamplerBuffer to unit 2, same as Iris does with lightmap. Non-Windows drivers reject the draw.
#if defined MC_OS_WINDOWS || MC_VERSION < 260100 || MC_VERSION >= 260200 || !(defined GBUFFERS_TERRAIN || defined GBUFFERS_WATER)
    #define LIGHTMAP_SAMPLER_SAFE
    uniform sampler2D lightmap;
#endif

#if (defined IS_IRIS || defined IS_ANGELICA && ANGELICA_VERSION >= 20000009) && defined FINAL
uniform sampler2D epWatermark;
#endif

uniform ivec3 cameraPositionInt;
uniform ivec3 previousCameraPositionInt;
uniform vec3 cameraPositionFract;
uniform vec3 previousCameraPositionFract;

#ifdef IS_IRIS
    #if MC_VERSION >= 12109 || ANGELICA_VERSION >= 20155000
        uniform float endFlashIntensityM;
        uniform vec3 endFlashPosition;
        // vec3 endFlashPosition = vec3(0.0, 0.0, -100.0);
    #endif
#endif

#if SHADOW_QUALITY > -1 || defined LIGHTSHAFTS_ACTIVE || defined FF_BLOCKLIGHT
    uniform sampler2D shadowcolor0;
    uniform sampler2D shadowcolor1;

    uniform sampler2DShadow shadowtex1;

    #ifdef COMPOSITE1
        uniform sampler2D shadowtex0;
    #else
        uniform sampler2DShadow shadowtex0;
    #endif
#endif

#ifdef DISTANT_HORIZONS
    uniform int dhRenderDistance;

    uniform mat4 dhProjection;
    uniform mat4 dhProjectionInverse;
    uniform mat4 dhPreviousProjection;

    uniform sampler2D dhDepthTex;
    uniform sampler2D dhDepthTex1;

    uniform float dhNearPlane;
    uniform float dhFarPlane;
#endif

#if !defined DH_TERRAIN && !defined DH_WATER
    uniform mat4 gbufferProjection;
    uniform mat4 gbufferProjectionInverse;
#else
    mat4 gbufferProjection = dhProjection;
    mat4 gbufferProjectionInverse = dhProjectionInverse;
#endif

#ifdef VOXY
    uniform int vxRenderDistance;

    uniform mat4 vxProj;
    uniform mat4 vxProjInv;
    uniform mat4 vxProjPrev;
    uniform mat4 vxModelView;
    uniform mat4 vxModelViewInv;
    uniform mat4 vxModelViewPrev;

    uniform sampler2D vxDepthTexTrans;
    uniform sampler2D vxDepthTexOpaque;
#endif

#if COLORED_LIGHTING_INTERNAL > 0 || defined END_PORTAL_BEAM_INTERNAL
    uniform usampler3D voxel_sampler;
    uniform sampler3D floodfill_sampler;
    uniform sampler3D floodfill_sampler_copy;
#endif

#ifdef PUDDLE_VOXELIZATION
    uniform usampler2D puddle_sampler;
#endif

#ifdef SKY_HEIGHT_INTERNAL
    uniform usampler2D skyheight_sampler;
#endif

#if WORLD_SPACE_REFLECTIONS_INTERNAL > 0
    uniform sampler2D textureAtlas;

    uniform usampler3D wsr_sampler;
    uniform usampler3D wsr_lod_sampler;

    #if WORLD_SPACE_PLAYER_REF == 1
        uniform sampler2D playerAtlas_sampler;
    #endif

    #ifdef CLOUD_SHADOWS
        uniform sampler2D cloudWaterTex;
    #endif
#endif

#ifdef ACT_GROUND_LEAVES_FIX
    uniform usampler3D leaves_sampler;
#endif

/*-----------------------------------------------------------------------------
  ___ _   _ ___ _____ ___  __  __   _   _ _  _ ___ ___ ___  ___ __  __ ___
 / __| | | / __|_   _/ _ \|  \/  | | | | | \| |_ _| __/ _ \| _ \  \/  / __|
| (__| |_| \__ \ | || (_) | |\/| | | |_| | .` || || _| (_) |   / |\/| \__ \
 \___|\___/|___/ |_| \___/|_|  |_|  \___/|_|\_|___|_| \___/|_|_\_|  |_|___/

-----------------------------------------------------------------------------*/

uniform bool isOnGround = true;

uniform float framemod2;
uniform float framemod4;
uniform float framemod8;
uniform float framemod600;
uniform float isEyeInCave;
uniform float inDry;
uniform float inRainy;
uniform float inSnowy;
uniform float starter;
uniform float frameTimeSmooth;
uniform float eyeBrightnessM;
uniform float eyeBrightnessM2;
uniform float rainFactor;
uniform float inBasaltDeltas = 0.0;
uniform float inCrimsonForest = 0.0;
uniform float inNetherWastes = 1.0;
uniform float inSoulValley = 0.0;
uniform float inWarpedForest = 0.0;
uniform float inPaleGarden = 0.0;
uniform float inSulfurCaves = 0.0;
uniform float inIceCaves = 0.0;
uniform float isSneaking = 1.0;
uniform float isSprinting = 0.0;
uniform float inLushCave = 0.0;
uniform float inSand = 0.0;
uniform float inRedSand = 0.0;
uniform float lightningFlashOptifine = 0.0;
uniform float inForest = 0.0;
uniform float shaderStart;
uniform float shaderStartSmooth;
uniform float inVanillaEnd = 1.0;
uniform float isShockwave = 1.0;
uniform float eyeBrightnessXM;
uniform float eyeBrightnessXM2;
uniform float waterAltitude = 61.9;
uniform float inJungle = 0.0;
uniform float inDappledForest = 0.0;
uniform float thunderFactor = 0.0;
uniform float worldTimeSmooth;
uniform float worldAgeSmooth;
uniform float isCurrentBiomeModded = 0.0;
#ifdef EUPHORIA_PATCHES_UNIFORMS
    uniform float euphoriaPatchesFrozenTimeOffset = 0.0;
    uniform int euphoriaPatchesCurrentDayMillis = -1;

    uniform int euphoriaPatchesCurrentSeasonTick;
    uniform int euphoriaPatchesSeasonDuration;
    uniform int euphoriaPatchesTotalSeasonDuration;
#endif

#if defined EUPHORIA_PATCHES_MACE_WAVE_STATE_UNIFORM && MC_VERSION >= 12100
    // Mace smash waves, block position of each wave and x = progress (-1 = unused), y = strength of wave 0, zw the same for wave 1
    #ifdef IS_IRIS
        uniform ivec3 euphoriaPatchesMaceWavePos0;
        uniform ivec3 euphoriaPatchesMaceWavePos1;
    #else
        // OptiFine has no ivec3 and uploads an ivec4 with w = 0, always read these with .xyz
        uniform ivec4 euphoriaPatchesMaceWavePos0;
        uniform ivec4 euphoriaPatchesMaceWavePos1;
    #endif
    uniform vec4 euphoriaPatchesMaceWaveState = vec4(-1.0, 0.0, -1.0, 0.0);
#endif

#ifdef EUPHORIA_PATCHES_CLOUD_ALPHA_UNIFORM
    uniform float euphoriaPatchesCloudAlpha = 1.0;
#endif

uniform vec2 viewSize;
uniform vec2 texelSize;
