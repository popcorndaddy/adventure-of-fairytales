doSolidBlockCheck = false;
storeToAllFaces = true;
